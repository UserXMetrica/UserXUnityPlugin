#import <Foundation/Foundation.h>
#import <UserXKit/UserXKit-Swift.h>
#include <TargetConditionals.h>

@interface UserXPlugin : NSObject

@end

@implementation UserXPlugin

+(void)start: (NSString *) key
{
    [UserX start: key];
    
    
}

@end

extern "C"
{
    void _UserXPluginInit(const char *key)
    {
#if !TARGET_OS_SIMULATOR
        [UserXPlugin start: [NSString stringWithUTF8String:key]];
#endif
    }

    void _UserXPluginStart()
    {
#if !TARGET_OS_SIMULATOR
        [UserX startScreenRecording];
#endif
    }

    void _UserXPluginStop()
    {
#if !TARGET_OS_SIMULATOR
        [UserX stopScreenRecording];
#endif
    }

    void _UserXPluginUID(const char *key)
    {
#if !TARGET_OS_SIMULATOR
        [UserX setUserId:[NSString stringWithUTF8String:key]];
#endif
    }
}
