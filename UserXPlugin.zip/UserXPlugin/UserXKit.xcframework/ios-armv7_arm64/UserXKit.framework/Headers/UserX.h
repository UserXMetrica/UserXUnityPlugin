//
//  UserX.h
//  UserX
//
//  Created by Andrey Korobkin on 07/06/2017.
//  Copyright © 2017 JUST LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UserX.
FOUNDATION_EXPORT double UserXVersionNumber;

//! Project version string for UserX.
FOUNDATION_EXPORT const unsigned char UserXVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UserX/PublicHeader.h>


